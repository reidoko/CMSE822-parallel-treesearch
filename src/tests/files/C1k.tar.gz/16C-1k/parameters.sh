###############################################################################
# Paths and whatnot
# 

# path to the project (for utilities)
project_path=/mnt/home/dokorei/Projects/model-variation
export PATH=${project_path}/utilities:$PATH

# Path to programs such as raxml, ms, indelible, etc
export PATH=/mnt/home/dokorei/bin:$PATH

###############################################################################
# General simulation study parameters
#
# bash_seed         seed for PRNG
# num_replicates    How many replicates 
# experiment_name   Where to store files created for simulation study

bash_seed=1 # seed for PRNG
num_replicates=8 # Number of replicates
experiment_name="16C-1k"

###############################################################################
# Model condition information
#
# num_taxa          how many taxa
# tree_height       height to scale tree to
# indel_probability speaks for itself
# seq_length        how many nucleotides long should a sequence be
# indel_dist_path   path to indel distribution
# smodel_bg         background substitution model line for INDELible
# basefreq_bg       background model base frequency
# smodel_sh         shift substitution model line for INDELible
# basefreq_sh       shift model base frequency

num_taxa=16 # Number of taxa
tree_height="1.2"
indel_probability="0.06" # insertion/deletion probability
seq_length=1000

smodel_bg="HKY 0.345"
basefreq_bg="0.2433 0.2337 0.2594 0.2636"
smodel_sh="HKY 0.501"
basefreq_sh="0.1635 0.3336 0.1735 0.3294"
indel_dist_path="${project_path}/utilities/liu2012.txt"


###############################################################################
# Inference and estimation settings
#
# raxml_args       arguments to pass to RAxML

raxml_args='-m GTRCAT -V'

###############################################################################
# Miscellaneous
#

# Progress bar from https://github.com/fearside/ProgressBar/
function ProgressBar {
    let _progress=(${1}*100/${2}*100)/100
    let _done=(${_progress}*4)/10
    let _left=40-$_done
    _fill=$(printf "%${_done}s")
    _empty=$(printf "%${_left}s")

printf "\r${3}[${_fill// /#}${_empty// /-}] ${_progress}%%"

}
